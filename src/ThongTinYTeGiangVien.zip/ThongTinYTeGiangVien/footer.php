<!-- info section -->
<section class="info_section">
    <div class="container">
        <div class="info_bottom layout_padding2">
            <div class="row info_main_row">
                <div class="col-md-6 col-lg-6">
                    <h5>Địa chỉ</h5>
                    <div class="info_contact">
                        <a href="#">
                            <i class="fa fa-map-marker" aria-hidden="true"></i>
                            <span>Số 126 Nguyễn Thiện Thành, Khóm 4, Phường 5, Thành phố Trà Vinh, Tỉnh Trà Vinh</span>
                        </a>
                        <a href="#">
                            <i class="fa fa-phone" aria-hidden="true"></i>
                            <span>Điện thoại: (0294) 3.858.115</span>
                        </a>
                    </div>
                    <div class="social_box">
                        <a href="">
                            <i class="fa fa-facebook" aria-hidden="true"></i>
                        </a>
                        <a href="">
                            <i class="fa fa-twitter" aria-hidden="true"></i>
                        </a>
                        <a href="">
                            <i class="fa fa-linkedin" aria-hidden="true"></i>
                        </a>
                        <a href="">
                            <i class="fa fa-instagram" aria-hidden="true"></i>
                        </a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="info_post">
                        <h5>LATEST POSTS</h5>
                        <div class="post_box">
                            <div class="img-box">
                                <img src="<?=URL_ROOT?>/templates/home/images/post1.jpg" alt="">
                            </div>
                            <p>
                                Normal
                                distribution
                            </p>
                        </div>
                        <div class="post_box">
                            <div class="img-box">
                                <img src="<?=URL_ROOT?>/templates/home/images/post2.jpg" alt="">
                            </div>
                            <p>
                                Normal
                                distribution
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="info_post">
                        <h5>
                            News
                        </h5>
                        <div class="post_box">
                            <div class="img-box">
                                <img src="<?=URL_ROOT?>/templates/home/images/post3.jpg" alt="">
                            </div>
                            <p>
                                Normal
                                distribution
                            </p>
                        </div>
                        <div class="post_box">
                            <div class="img-box">
                                <img src="<?=URL_ROOT?>/templates/home/images/post4.png" alt="">
                            </div>
                            <p>
                                Normal
                                distribution
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- end info_section -->


<!-- footer section -->
<footer class="footer_section">
    <div class="container">
        <p>&copy; <span id="displayYear"></span></p>
    </div>
</footer>
<!-- footer section -->

<!-- jQery -->
<script src="<?=URL_ROOT?>/templates/home/js/jquery-3.4.1.min.js"></script>
<!-- bootstrap js -->
<script src="<?=URL_ROOT?>/templates/home/js/bootstrap.js"></script>
<!-- nice select -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-nice-select/1.1.0/js/jquery.nice-select.min.js" integrity="sha256-Zr3vByTlMGQhvMfgkQ5BtWRSKBGa2QlspKYJnkjZTmo=" crossorigin="anonymous"></script>
<!-- owl slider -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
<!-- datepicker -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.js"></script>
<!-- custom js -->
<script src="<?=URL_ROOT?>/templates/home/js/custom.js"></script>

</body>

</html>

<?php ob_end_flush();?>
<?php include 'header.php'?>
<?php
    include 'models/HealthServiceDB.php';

    $healthServiceList = HealthServiceDB::GetList();
?>

<section class="team_section layout_padding">
    <div class="container">
        <div class="heading_container heading_center">
            <h2>DỊCH VỤ Y TẾ</h2>
        </div>
        <div class="carousel-wrap ">
            <div class="owl-carousel team_carousel">
                <?php foreach ($healthServiceList as $item) {?>
                <div class="item">
                    <div class="box">
                        <div class="detail-box p-4">
                            <h5><?=$item['ten_dich_vu']?></h5>
                            <h6><?=$item['mo_ta']?></h6>
                        </div>
                    </div>
                </div>
                <?php }?>
            </div>
        </div>
    </div>
</section>

<?php include 'footer.php'?>
<?php

require '../../vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class ExportExcel
{
    public static function VaccinationBook($database)
    {
        // Create a new Spreadsheet object
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();

        // Set values for cells
        $sheet->setCellValue('A1', 'Khách hàng');
        $sheet->setCellValue('B1', 'Loại vắc xin');
        $sheet->setCellValue('C1', 'Ngày khám');
        $sheet->setCellValue('D1', 'Giờ khám');
        $sheet->setCellValue('E1', 'Trạng thái');

        // Example of adding data from $database, assuming $database is an array
        $row = 2;
        foreach ($database as $data) {
            $sheet->setCellValue('A' . $row, $data['ho_ten_tk']);
            $sheet->setCellValue('B' . $row, $data['ten_vac_xin']);
            $sheet->setCellValue('C' . $row, $data['ngay_kham']);
            $sheet->setCellValue('D' . $row, $data['gio_kham']);
            $sheet->setCellValue('E' . $row, $data['trang_thai']);
            $row++;
        }

        // Save Excel file to the server or output directly to browser
        $writer = new Xlsx($spreadsheet);
        $fileName = 'Lịch đặt tiêm chủng.xlsx';

        // Clear output buffer to avoid any corruption
        ob_clean();

        // Send file to browser for download
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="' . $fileName . '"');
        header('Cache-Control: max-age=0');

        $writer->save('php://output');
        exit;
    }

    public static function HealthCheck($database)
    {
        // Create a new Spreadsheet object
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();

        // Set values for cells
        $sheet->setCellValue('A1', 'Khách hàng');
        $sheet->setCellValue('B1', 'Dịch vụ');
        $sheet->setCellValue('C1', 'Ngày khám');
        $sheet->setCellValue('D1', 'Giờ khám');
        $sheet->setCellValue('E1', 'Trạng thái');

        // Example of adding data from $database, assuming $database is an array
        $row = 2;
        foreach ($database as $data) {
            $sheet->setCellValue('A' . $row, $data['ho_ten_tk']);
            $sheet->setCellValue('B' . $row, $data['ten_dich_vu']);
            $sheet->setCellValue('C' . $row, $data['ngay_kham']);
            $sheet->setCellValue('D' . $row, $data['gio_kham']);
            $sheet->setCellValue('E' . $row, $data['trang_thai']);
            $row++;
        }

        // Save Excel file to the server or output directly to browser
        $writer = new Xlsx($spreadsheet);
        $fileName = 'Lịch đặt khám sức khoẻ.xlsx';

        // Clear output buffer to avoid any corruption
        ob_clean();

        // Send file to browser for download
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="' . $fileName . '"');
        header('Cache-Control: max-age=0');

        $writer->save('php://output');
        exit;
    }

    public static function HealthRecordTeacher($database)
    {
        // Create a new Spreadsheet object
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();

        // Set headers for the columns
        $headers = [
            'Ngày khám', 'Bác sĩ',
            'Chiều cao', 'Cân nặng', 'BMI', 'Tuần hoàn',
            'Hô hấp', 'Tiêu hoá', 'Thận', 'Nội tiết',
            'Xương', 'Thần kinh', 'Ngoại khoa', 'Sản khoa',
            'Mắt không kính (Trái)', 'Mắt không kính (Phải)',
            'Mắt có kính (Trái)', 'Mắt có kính (Phải)',
            'Bệnh về mắt', 'Tai mũi họng', 'Tai trái',
            'Tai phải', 'Bệnh về tai', 'Da liễu',
            'Tiền sử bệnh',
        ];

        // Set headers in the first row
        $col = 'A';
        foreach ($headers as $header) {
            $sheet->setCellValue($col . '1', $header);
            $col++;
        }

        // Define starting row for the data
        $row = 2;

        // Iterate over the $database array to populate the spreadsheet
        foreach ($database as $item) {
            $col = 'A';

            $sheet->setCellValue($col++ . $row, Helper::DateTime($item['ngay_kham'], 'date'));
            $sheet->setCellValue($col++ . $row, $item['ho_ten_bs']);
            $sheet->setCellValue($col++ . $row, $item['chieu_cao']);
            $sheet->setCellValue($col++ . $row, $item['can_nang']);
            $sheet->setCellValue($col++ . $row, $item['bmi']);
            $sheet->setCellValue($col++ . $row, $item['tuan_hoan']);
            $sheet->setCellValue($col++ . $row, $item['ho_hap']);
            $sheet->setCellValue($col++ . $row, $item['tieu_hoa']);
            $sheet->setCellValue($col++ . $row, $item['than']);
            $sheet->setCellValue($col++ . $row, $item['noi_tiet']);
            $sheet->setCellValue($col++ . $row, $item['xuong']);
            $sheet->setCellValue($col++ . $row, $item['than_kinh']);
            $sheet->setCellValue($col++ . $row, $item['ngoai_khoa']);
            $sheet->setCellValue($col++ . $row, $item['san_khoa']);
            $sheet->setCellValue($col++ . $row, $item['mat_trai']);
            $sheet->setCellValue($col++ . $row, $item['mat_phai']);
            $sheet->setCellValue($col++ . $row, $item['mat_trai_co_kinh']);
            $sheet->setCellValue($col++ . $row, $item['mat_phai_co_kinh']);
            $sheet->setCellValue($col++ . $row, $item['benh_mat']);
            $sheet->setCellValue($col++ . $row, $item['tai_mui_hong']);
            $sheet->setCellValue($col++ . $row, $item['tai_trai']);
            $sheet->setCellValue($col++ . $row, $item['tai_phai']);
            $sheet->setCellValue($col++ . $row, $item['benh_ve_tai']);
            $sheet->setCellValue($col++ . $row, $item['da_lieu']);
            $sheet->setCellValue($col++ . $row, $item['tien_su_benh']);

            $row++;
        }

        // Save Excel file to the server or output directly to browser
        $writer = new Xlsx($spreadsheet);
        $fileName = 'Hồ sơ sức khoẻ của ' . $database[0]['ho_ten_tk'] . '.xlsx';

        // Clear output buffer to avoid any corruption
        ob_clean();

        // Send file to browser for download
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="' . $fileName . '"');
        header('Cache-Control: max-age=0');

        $writer->save('php://output');
        exit;
    }
}

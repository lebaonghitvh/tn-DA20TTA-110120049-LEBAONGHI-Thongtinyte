<?php
class Helper
{
    public static function CreateID($prefix)
    {
        $sql = "SELECT MAX(RIGHT(ma_tk, LENGTH(ma_tk) - 2)) AS ma_tk FROM tai_khoan WHERE ma_tk LIKE '$prefix%'";
        $data = SQLQuery::GetData($sql, ['row' => 0, 'cell' => 'ma_tk']);
        return $prefix . str_pad($data + 1, 3, '0', STR_PAD_LEFT);
    }

    public static function Currency($value)
    {
        return number_format($value, 0, ',', '.') . ' ₫';
    }

    public static function Phone($str)
    {
        if (strlen($str) == 11) {
            return substr($str, 0, 5) . ' ' . substr($str, 5, 3) . ' ' . substr($str, 8, 3);
        } else if (strlen($str) == 10) {
            return substr($str, 0, 4) . ' ' . substr($str, 4, 3) . ' ' . substr($str, 7, 3);
        }
        return '';
    }

    public static function DateTime($str, $type = 'datetime')
    {
        if ($str === null) {
            return '';
        }

        $formats = [
            'date'     => 'd/m/Y',
            'time'     => 'H:i:s',
            'datetime' => 'd/m/Y H:i:s',
        ];
        return date($formats[$type], strtotime($str));
    }
}

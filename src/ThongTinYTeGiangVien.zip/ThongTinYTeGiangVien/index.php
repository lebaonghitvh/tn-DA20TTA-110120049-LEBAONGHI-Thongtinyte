<?php include 'header.php'?>

<!-- slider section -->
<section class="slider_section">
    <div class="dot_design">
        <img src="<?=URL_ROOT?>/templates/home/images/dots.png" alt="">
    </div>
    <div id="customCarousel1" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="detail-box">
                                <div class="play_btn">
                                    <button>
                                        <i class="fa fa-play" aria-hidden="true"></i>
                                    </button>
                                </div>
                                <h1>Bệnh viện TVU</h1>
                                <p>Cung cấp các dịch vụ y tế tốt nhất</p>
                                <a href="#">Liên hệ</a>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="img-box">
                                <img src="<?=URL_ROOT?>/templates/home/images/slider-img.jpg" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- end slider section -->
</div>

<section class="book_section layout_padding">
    <div class="container">
        <?php if (isset($_GET['finish']) && $_GET['finish'] === 'registry') {?>
        <div class="p-3 bg-success rounded mb-3 text-white">
            Đăng ký tài khoản thành công
        </div>
        <?php } else if (isset($_GET['finish']) && $_GET['finish'] === 'login') {?>
        <div class="p-3 bg-success rounded mb-3 text-white">
            Đăng nhập tài khoản thành công
        </div>
        <?php }?>
    </div>
</section>


<section class="about_section">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="img-box">
                    <img src="<?=URL_ROOT?>/templates/home/images/about-img.jpg" alt="">
                </div>
            </div>
            <div class="col-md-6">
                <div class="detail-box">
                    <div class="heading_container">
                        <h2>Giới thiệu</h2>
                    </div>
                    <p>Bệnh viện Trường Đại học Trà Vinh được thành lập và phát triển trên cơ sở Phòng khám Đa khoa thuộc Trường Đại học Trà Vinh. Bệnh viện Trường Đại học Trà Vinh với mô hình mới về khám bệnh, chữa bệnh và cung cấp dịch vụ y tế
                        chất lượng cao kết hợp với công tác đào tạo và nghiên cứu khoa học nhằm đáp ứng nhu cầu xã hội.
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>


<!-- treatment section -->
<section class="treatment_section layout_padding">
    <div class="side_img">
        <img src="<?=URL_ROOT?>/templates/home/images/treatment-side-img.jpg" alt="">
    </div>
    <div class="container">
        <div class="heading_container heading_center">
            <h2>
                Tại sao bạn nên chọn <span>bệnh viện TVU</span>
            </h2>
        </div>
        <div class="row">
            <div class="col-md-6 col-lg-3">
                <div class="box">
                    <div class="img-box">
                        <img src="<?=URL_ROOT?>/templates/home/images/t1.png" alt="">
                    </div>
                    <div class="detail-box">
                        <h4>Tận tâm</h4>
                        <p>Tận tụy, hết lòng cứu chữa, chăm sóc người bệnh bằng tất cả lương tâm nghề nghiệp.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="box">
                    <div class="img-box">
                        <img src="<?=URL_ROOT?>/templates/home/images/t2.png" alt="">
                    </div>
                    <div class="detail-box">
                        <h4>Minh bạch</h4>
                        <p>Thực hiện công khai, rõ ràng, trung thực tất cả các dịch vụ chuyên môn của Bệnh viện.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="box">
                    <div class="img-box">
                        <img src="<?=URL_ROOT?>/templates/home/images/t3.png" alt="">
                    </div>
                    <div class="detail-box">
                        <h4>Sáng tạo</h4>
                        <p>Không ngừng đổi mới, sáng tạo, đem lại sự tin cậy cao nhất về kết quả điều trị cho người bệnh.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="box">
                    <div class="img-box">
                        <img src="<?=URL_ROOT?>/templates/home/images/t4.png" alt="">
                    </div>
                    <div class="detail-box">
                        <h4>Thân thiện</h4>
                        <p>Đối xử tử tế, chu đáo, hướng tới sự hài lòng cao của người bệnh và thân nhân người bệnh.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'footer.php'?>
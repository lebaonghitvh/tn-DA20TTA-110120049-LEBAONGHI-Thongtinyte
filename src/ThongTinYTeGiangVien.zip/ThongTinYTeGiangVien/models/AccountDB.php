<?php
class AccountDB
{
    public static function GetList($quyen)
    {
        $sql = "SELECT * FROM tai_khoan WHERE quyen = '$quyen'";
        return SQLQuery::GetData($sql);
    }

    public static function GetRelativeList($ma_tk)
    {
        $sql = "SELECT * FROM tai_khoan WHERE quyen = 'than_nhan' AND ma_than_nhan = '$ma_tk'";
        return SQLQuery::GetData($sql);
    }

    public static function GetItemByID($ma_tk)
    {
        $sql = "SELECT * FROM tai_khoan WHERE ma_tk = '$ma_tk'";
        return SQLQuery::GetData($sql, ['row' => 0]);
    }

    public static function AddAccount($ma_tk, $ho_ten_tk, $mat_khau, $email, $sdt, $gioi_tinh, $ngay_sinh, $dia_chi, $quyen, $ma_than_nhan)
    {
        $sql = "INSERT INTO tai_khoan (ma_tk, ho_ten_tk, mat_khau, email, sdt, gioi_tinh, ngay_sinh, dia_chi, quyen, ma_than_nhan) VALUE
            ('$ma_tk', '$ho_ten_tk', '$mat_khau', '$email', '$sdt', '$gioi_tinh', '$ngay_sinh', '$dia_chi', '$quyen', '$ma_than_nhan')";
        return SQLQuery::NonQuery($sql);
    }

    public static function UpdateAccount($ma_tk, $ho_ten_tk, $mat_khau, $email, $sdt, $gioi_tinh, $ngay_sinh, $dia_chi, $quyen)
    {
        $sql = "UPDATE tai_khoan SET ho_ten_tk = '$ho_ten_tk', email = '$email', sdt = '$sdt', gioi_tinh = '$gioi_tinh',
            dia_chi = '$dia_chi', ngay_sinh = '$ngay_sinh', dia_chi = '$dia_chi', quyen = '$quyen' WHERE ma_tk = '$ma_tk'";
        return SQLQuery::NonQuery($sql);
    }

    public static function DeleteAccount($ma_tk)
    {
        $sql = "DELETE FROM tai_khoan WHERE ma_tk = '$ma_tk'";
        return SQLQuery::NonQuery($sql);
    }

    public static function LoginAccount($email, $mat_khau)
    {
        $sql = "SELECT * FROM tai_khoan WHERE email = '$email' AND mat_khau = '$mat_khau'";
        return SQLQuery::GetData($sql);
    }
}

<?php
class HealthRecordDB
{
    public static function GetList($ma_bac_si = '', $ma_giang_vien = '')
    {
        $sql = 'SELECT ho_so_suc_khoe.*, gv.*, gv.ma_tk as ma_gv, bs.ma_tk as ma_bs, bs.ho_ten_tk as ho_ten_bs FROM ho_so_suc_khoe, tai_khoan gv, tai_khoan bs WHERE ho_so_suc_khoe.ma_bac_si = bs.ma_tk AND ho_so_suc_khoe.ma_giang_vien = gv.ma_tk';
        if ($ma_bac_si !== '') {
            $sql .= " AND ho_so_suc_khoe.ma_bac_si = '$ma_bac_si'";
        }
        if ($ma_giang_vien !== '') {
            $sql .= " AND ho_so_suc_khoe.ma_giang_vien = '$ma_giang_vien'";
        }
        return SQLQuery::GetData($sql);
    }

    public static function GetItemByID($ma_hssk)
    {
        $sql = "SELECT ho_so_suc_khoe.*, gv.*, gv.ma_tk as ma_gv, bs.ma_tk as ma_bs, bs.ho_ten_tk as ho_ten_bs FROM ho_so_suc_khoe, tai_khoan gv, tai_khoan bs WHERE ho_so_suc_khoe.ma_bac_si = bs.ma_tk AND ho_so_suc_khoe.ma_giang_vien = gv.ma_tk AND ma_hssk = '$ma_hssk'";
        return SQLQuery::GetData($sql, ['row' => 0]);
    }

    public static function AddHealthRecord($tien_su_benh, $chieu_cao, $can_nang, $bmi, $tuan_hoan, $ho_hap, $tieu_hoa, $than, $noi_tiet, $xuong, $than_kinh, $ngoai_khoa, $san_khoa, $mat_trai, $mat_phai, $mat_trai_co_kinh, $mat_phai_co_kinh, $benh_mat, $tai_mui_hong, $tai_phai, $tai_trai, $benh_ve_tai, $rang_ham_mat, $ham_tren, $ham_duoi, $benh_ve_rang, $da_lieu, $ngay_kham, $ma_bac_si, $ma_giang_vien)
    {
        $sql = "INSERT INTO ho_so_suc_khoe (tien_su_benh, chieu_cao, can_nang, bmi, tuan_hoan, ho_hap, tieu_hoa, than, noi_tiet, xuong, than_kinh, ngoai_khoa, san_khoa, mat_trai, mat_phai, mat_trai_co_kinh, mat_phai_co_kinh, benh_mat, tai_mui_hong, tai_phai, tai_trai, benh_ve_tai, rang_ham_mat, ham_tren, ham_duoi, benh_ve_rang, da_lieu, ngay_kham, ma_bac_si, ma_giang_vien)
            VALUES ('$tien_su_benh', '$chieu_cao', '$can_nang', '$bmi', '$tuan_hoan', '$ho_hap', '$tieu_hoa', '$than', '$noi_tiet', '$xuong', '$than_kinh', '$ngoai_khoa', '$san_khoa', '$mat_trai', '$mat_phai', '$mat_trai_co_kinh', '$mat_phai_co_kinh', '$benh_mat', '$tai_mui_hong', '$tai_phai', '$tai_trai', '$benh_ve_tai', '$rang_ham_mat', '$ham_tren', '$ham_duoi', '$benh_ve_rang', '$da_lieu', '$ngay_kham', '$ma_bac_si', '$ma_giang_vien')";
        return SQLQuery::NonQuery($sql);
    }

    public static function UpdateHealthRecord(
        $ma_hssk, $tien_su_benh, $chieu_cao, $can_nang, $bmi, $tuan_hoan,
        $ho_hap, $tieu_hoa, $than, $noi_tiet, $xuong, $than_kinh, $ngoai_khoa,
        $san_khoa, $mat_trai, $mat_phai, $mat_trai_co_kinh, $mat_phai_co_kinh,
        $benh_mat, $tai_mui_hong, $tai_phai, $tai_trai, $benh_ve_tai,
        $rang_ham_mat, $ham_tren, $ham_duoi, $benh_ve_rang, $da_lieu,
        $ngay_kham, $ma_bac_si, $ma_giang_vien
    ) {
        $sql = "UPDATE ho_so_suc_khoe SET
            tien_su_benh = '$tien_su_benh',
            chieu_cao = '$chieu_cao',
            can_nang = '$can_nang',
            bmi = '$bmi',
            tuan_hoan = '$tuan_hoan',
            ho_hap = '$ho_hap',
            tieu_hoa = '$tieu_hoa',
            than = '$than',
            noi_tiet = '$noi_tiet',
            xuong = '$xuong',
            than_kinh = '$than_kinh',
            ngoai_khoa = '$ngoai_khoa',
            san_khoa = '$san_khoa',
            mat_trai = '$mat_trai',
            mat_phai = '$mat_phai',
            mat_trai_co_kinh = '$mat_trai_co_kinh',
            mat_phai_co_kinh = '$mat_phai_co_kinh',
            benh_mat = '$benh_mat',
            tai_mui_hong = '$tai_mui_hong',
            tai_phai = '$tai_phai',
            tai_trai = '$tai_trai',
            benh_ve_tai = '$benh_ve_tai',
            rang_ham_mat = '$rang_ham_mat',
            ham_tren = '$ham_tren',
            ham_duoi = '$ham_duoi',
            benh_ve_rang = '$benh_ve_rang',
            da_lieu = '$da_lieu',
            ngay_kham = '$ngay_kham',
            ma_bac_si = '$ma_bac_si',
            ma_giang_vien = '$ma_giang_vien'
            WHERE ma_hssk = '$ma_hssk'";
        return SQLQuery::NonQuery($sql);
    }

    public static function DeleteHealthRecord($ma_hssk)
    {
        $sql = "DELETE FROM ho_so_suc_khoe WHERE ma_hssk = '$ma_hssk'";
        return SQLQuery::NonQuery($sql);
    }
}

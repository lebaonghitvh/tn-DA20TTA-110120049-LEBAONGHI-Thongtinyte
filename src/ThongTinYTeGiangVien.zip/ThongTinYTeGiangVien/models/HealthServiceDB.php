<?php
class HealthServiceDB
{
    public static function GetList()
    {
        $sql = 'SELECT * FROM dich_vu_y_te';
        return SQLQuery::GetData($sql);
    }

    public static function GetItemByID($ma_dich_vu)
    {
        $sql = "SELECT * FROM dich_vu_y_te WHERE ma_dich_vu = '$ma_dich_vu'";
        return SQLQuery::GetData($sql, ['row' => 0]);
    }

    public static function AddHealthService($ten_dich_vu, $gia_tien, $mo_ta)
    {
        $sql = "INSERT INTO dich_vu_y_te (ten_dich_vu, gia_tien, mo_ta) VALUE
            ('$ten_dich_vu', '$gia_tien', '$mo_ta')";
        return SQLQuery::NonQuery($sql);
    }

    public static function UpdateHealthService($ma_dich_vu, $ten_dich_vu, $gia_tien, $mo_ta)
    {
        $sql = "UPDATE dich_vu_y_te SET ten_dich_vu = '$ten_dich_vu', gia_tien = '$gia_tien', mo_ta = '$mo_ta' WHERE ma_dich_vu = '$ma_dich_vu'";
        return SQLQuery::NonQuery($sql);
    }

    public static function DeleteHealthService($ma_dich_vu)
    {
        $sql = "DELETE FROM dich_vu_y_te WHERE ma_dich_vu = '$ma_dich_vu'";
        return SQLQuery::NonQuery($sql);
    }
}

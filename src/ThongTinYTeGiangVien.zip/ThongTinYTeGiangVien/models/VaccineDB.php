<?php
class VaccineDB
{
    public static function GetList()
    {
        $sql = 'SELECT * FROM vac_xin';
        return SQLQuery::GetData($sql);
    }

    public static function GetItemByID($vac_xin_id)
    {
        $sql = "SELECT * FROM vac_xin WHERE vac_xin_id = '$vac_xin_id'";
        return SQLQuery::GetData($sql, ['row' => 0]);
    }

    public static function AddVaccine($ten_vac_xin, $ten_khoa_hoc, $nha_san_xuat, $doi_tuong_tiem, $lieu_trinh_tiem, $gia, $tac_dung_phu, $luu_y)
    {
        $sql = "INSERT INTO vac_xin (ten_vac_xin, ten_khoa_hoc, nha_san_xuat, doi_tuong_tiem, lieu_trinh_tiem, gia, tac_dung_phu, luu_y) VALUE
            ('$ten_vac_xin', '$ten_khoa_hoc', '$nha_san_xuat', '$doi_tuong_tiem', '$lieu_trinh_tiem', '$gia', '$tac_dung_phu', '$luu_y')";
        return SQLQuery::NonQuery($sql);
    }

    public static function UpdateVaccine($vac_xin_id, $ten_vac_xin, $ten_khoa_hoc, $nha_san_xuat, $doi_tuong_tiem, $lieu_trinh_tiem, $gia, $tac_dung_phu, $luu_y)
    {
        $sql = "UPDATE vac_xin SET ten_vac_xin = '$ten_vac_xin', ten_khoa_hoc = '$ten_khoa_hoc', nha_san_xuat = '$nha_san_xuat', doi_tuong_tiem = '$doi_tuong_tiem',
        lieu_trinh_tiem = '$lieu_trinh_tiem', gia = '$gia', luu_y = '$luu_y', tac_dung_phu = '$tac_dung_phu', luu_y = '$luu_y' WHERE vac_xin_id = '$vac_xin_id'";
        return SQLQuery::NonQuery($sql);
    }

    public static function DeleteVaccine($vac_xin_id)
    {
        $sql = "DELETE FROM vac_xin WHERE vac_xin_id = '$vac_xin_id'";
        return SQLQuery::NonQuery($sql);
    }
}

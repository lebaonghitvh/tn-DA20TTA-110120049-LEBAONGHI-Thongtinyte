<?php
class HealthCheckDB
{
    public static function GetList($ma_giang_vien = '')
    {
        $sql = 'SELECT * FROM dat_lich_kham, tai_khoan, dich_vu_y_te WHERE dat_lich_kham.ma_khach_hang = tai_khoan.ma_tk AND dat_lich_kham.ma_dich_vu = dich_vu_y_te.ma_dich_vu';
        if ($ma_giang_vien !== '') {
            $sql .= " AND dat_lich_kham.ma_khach_hang = '$ma_giang_vien'";
        }
        return SQLQuery::GetData($sql);
    }

    public static function GetMyOrRelativeList($ma_giang_vien = '')
    {
        $sql = "SELECT * FROM tai_khoan, dat_lich_kham, dich_vu_y_te WHERE (ma_tk = '$ma_giang_vien' OR ma_than_nhan = '$ma_giang_vien') AND dat_lich_kham.ma_khach_hang = tai_khoan.ma_tk AND dich_vu_y_te.ma_dich_vu = dat_lich_kham.ma_dich_vu";
        return SQLQuery::GetData($sql);
    }

    public static function GetItemByID($ma_dat_lich_kham)
    {
        $sql = "SELECT * FROM dat_lich_kham, tai_khoan, dich_vu_y_te WHERE dat_lich_kham.ma_khach_hang = tai_khoan.ma_tk AND dat_lich_kham.ma_dich_vu = dich_vu_y_te.ma_dich_vu AND dat_lich_kham.ma_dat_lich_kham = '$ma_dat_lich_kham'";
        return SQLQuery::GetData($sql, ['row' => 0]);
    }

    public static function AddHealthCheck($ma_khach_hang, $ma_dich_vu, $ngay_kham, $gio_kham, $trang_thai)
    {
        $sql = "INSERT INTO dat_lich_kham (ma_khach_hang, ma_dich_vu, ngay_kham, gio_kham, trang_thai) VALUE
            ('$ma_khach_hang', '$ma_dich_vu', '$ngay_kham', '$gio_kham', '$trang_thai')";
        var_dump($sql);
        return SQLQuery::NonQuery($sql);
    }

    public static function UpdateHealthCheck($ma_dat_lich_kham, $ten_dich_vu, $ma_dich_vu, $ngay_kham, $gio_kham, $trang_thai)
    {
        $sql = "UPDATE dat_lich_kham SET ten_dich_vu = '$ten_dich_vu', ma_dich_vu = '$ma_dich_vu',
            ngay_kham = '$ngay_kham', gio_kham = '$gio_kham', trang_thai = '$trang_thai' WHERE ma_dat_lich_kham = '$ma_dat_lich_kham'";
        return SQLQuery::NonQuery($sql);
    }

    public static function DeleteHealthCheck($ma_dat_lich_kham)
    {
        $sql = "DELETE FROM dat_lich_kham WHERE ma_dat_lich_kham = '$ma_dat_lich_kham'";
        return SQLQuery::NonQuery($sql);
    }

    public static function UpdateHealthCheckStatus($ma_dat_lich_kham, $trang_thai)
    {
        $sql = "UPDATE dat_lich_kham SET trang_thai = '$trang_thai' WHERE ma_dat_lich_kham = '$ma_dat_lich_kham'";
        return SQLQuery::NonQuery($sql);
    }
}

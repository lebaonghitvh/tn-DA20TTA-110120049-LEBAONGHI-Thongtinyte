<?php
class VaccinationBookDB
{
    public static function GetList($ma_giang_vien = '')
    {
        $sql = 'SELECT * FROM dat_lich_tiem_chung, vac_xin, tai_khoan WHERE dat_lich_tiem_chung.ma_khach_hang = tai_khoan.ma_tk AND dat_lich_tiem_chung.ma_vac_xin = vac_xin.vac_xin_id';
        if ($ma_giang_vien !== '') {
            $sql .= " AND dat_lich_tiem_chung.ma_khach_hang = '$ma_giang_vien'";
        }
        return SQLQuery::GetData($sql);
    }

    public static function GetMyOrRelativeList($ma_giang_vien = '')
    {
        $sql = "SELECT * FROM tai_khoan, dat_lich_tiem_chung, vac_xin WHERE (ma_tk = '$ma_giang_vien' OR ma_than_nhan = '$ma_giang_vien') AND dat_lich_tiem_chung.ma_khach_hang = tai_khoan.ma_tk AND vac_xin.vac_xin_id = dat_lich_tiem_chung.ma_vac_xin";
        return SQLQuery::GetData($sql);
    }

    public static function GetItemByID($ma_dat_lich_tiem_chung)
    {
        $sql = "SELECT * FROM dat_lich_tiem_chung, vac_xin, tai_khoan WHERE dat_lich_tiem_chung.ma_khach_hang = tai_khoan.ma_tk AND dat_lich_tiem_chung.ma_vac_xin = vac_xin.vac_xin_id AND dat_lich_tiem_chung.ma_dat_lich_tiem_chung = '$ma_dat_lich_tiem_chung'";
        return SQLQuery::GetData($sql, ['row' => 0]);
    }

    public static function AddVaccinationBook($ma_khach_hang, $ma_vac_xin, $ngay_kham, $gio_kham, $trang_thai)
    {
        $sql = "INSERT INTO dat_lich_tiem_chung (ma_khach_hang, ma_vac_xin, ngay_kham, gio_kham, trang_thai) VALUE
            ('$ma_khach_hang', '$ma_vac_xin', '$ngay_kham', '$gio_kham', '$trang_thai')";
        return SQLQuery::NonQuery($sql);
    }

    public static function UpdateVaccinationBook($ma_dat_lich_tiem_chung, $ten_dich_vu, $ma_vac_xin, $ngay_kham, $gio_kham, $trang_thai)
    {
        $sql = "UPDATE dat_lich_tiem_chung SET ten_dich_vu = '$ten_dich_vu', ma_vac_xin = '$ma_vac_xin',
            ngay_kham = '$ngay_kham', gio_kham = '$gio_kham', trang_thai = '$trang_thai' WHERE ma_dat_lich_tiem_chung = '$ma_dat_lich_tiem_chung'";
        return SQLQuery::NonQuery($sql);
    }

    public static function DeleteVaccinationBook($ma_dat_lich_tiem_chung)
    {
        $sql = "DELETE FROM dat_lich_tiem_chung WHERE ma_dat_lich_tiem_chung = '$ma_dat_lich_tiem_chung'";
        return SQLQuery::NonQuery($sql);
    }

    public static function UpdateVaccinationBookStatus($ma_dat_lich_tiem_chung, $trang_thai)
    {
        $sql = "UPDATE dat_lich_tiem_chung SET trang_thai = '$trang_thai' WHERE ma_dat_lich_tiem_chung = '$ma_dat_lich_tiem_chung'";
        return SQLQuery::NonQuery($sql);
    }
}

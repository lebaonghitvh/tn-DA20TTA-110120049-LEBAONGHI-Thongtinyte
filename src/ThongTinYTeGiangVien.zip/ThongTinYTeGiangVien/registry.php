<?php include 'header.php'?>
<?php
    include 'models/AccountDB.php';

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        AccountDB::AddAccount(Helper::CreateID('GV'), $_POST['ho_ten_tk'], $_POST['mat_khau'], $_POST['email'], $_POST['sdt'], $_POST['gioi_tinh'], $_POST['ngay_sinh'], $_POST['dia_chi'], 'giang_vien');
        header('Location: ' . URL_ROOT . '?finish=registry');
    }
?>

<section class="contact_section layout_padding-top layout_padding-bottom">
    <div class="container">
        <div class="heading_container">
            <h2>Đăng ký tài khoản</h2>
        </div>
        <div class="row">
            <div class="col-md-7">
                <div class="form_container">
                    <form class="form-row" method="POST">
                        <div class="form-group col-lg-12">
                            <input type="text" name="ho_ten_tk" placeholder="Họ và tên" />
                        </div>
                        <div class="form-group col-lg-6">
                            <select class="form-control wide" name="gioi_tinh">
                                <option value="Nam">Nam</option>
                                <option value="Nữ">Nữ</option>
                            </select>
                        </div>
                        <div class="form-group col-lg-6">
                            <input type="email" name="email" placeholder="Email" />
                        </div>
                        <div class="form-group col-lg-6">
                            <input type="text" name="sdt" placeholder="Số điện thoại" />
                        </div>
                        <div class="form-group col-lg-6">
                            <input type="date" class="form-control" name="ngay_sinh" placeholder="Ngày sinh" />
                        </div>
                        <div class="form-group col-lg-6">
                            <input type="password" name="mat_khau" placeholder="Mật khẩu" />
                        </div>
                        <div class="form-group col-lg-6">
                            <input type="password" name="nhap_lai_mat_khau" placeholder="Nhập lại mật khẩu" />
                        </div>
                        <div class="form-group col-lg-12">
                            <input type="text" name="dia_chi" placeholder="Địa chỉ" />
                        </div>
                        <div class="btn_box">
                            <button>Đăng ký</button>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-5">
                <div class="img-box">
                    <img src="<?=URL_ROOT?>/templates/home/images/contact-img.jpg" alt="">
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'footer.php'?>
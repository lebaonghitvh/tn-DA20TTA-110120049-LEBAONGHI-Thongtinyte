<?php
session_start();
ob_start();
include_once 'config/config.php';

session_unset();
session_destroy();


if (URL_ROOT == "") {
    header('Location: /login.php');
}
header('Location: ' . URL_ROOT);
ob_end_flush();
?>
<a href="/">Quay lại trang chủ</a>
<div class="mb-3">
    <?php if (isset($_GET['finish'])) {?>
    <div class="alert alert-info d-flex align-items-center justify-content-between" role="alert">
        <?php if ($_GET['finish'] === 'add') {?>
        <span>Thêm mới thành công</span>
        <div class="p-1" onclick="this.parentNode.style.setProperty('display', 'none', 'important')">
            <i class="fas fa-times"></i>
        </div>
        <?php } else if ($_GET['finish'] === 'update') {?>
        <span>Chỉnh sửa thành công</span>
        <div class="p-1" onclick="this.parentNode.style.setProperty('display', 'none', 'important')">
            <i class="fas fa-times"></i>
        </div>
        <?php } else if ($_GET['finish'] === 'delete') {?>
        <span>Xoá thành công</span>
        <div class="p-1" onclick="this.parentNode.style.setProperty('display', 'none', 'important')">
            <i class="fas fa-times"></i>
        </div>
        <?php }?>
    </div>
    <?php }?>
</div>
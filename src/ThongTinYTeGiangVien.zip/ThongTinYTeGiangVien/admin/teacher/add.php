<?php include '../header.php'?>
<?php
    include '../../models/AccountDB.php';

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        AccountDB::AddAccount(Helper::CreateID('GV'), $_POST['ho_ten_tk'], '', $_POST['email'], $_POST['sdt'], $_POST['gioi_tinh'], $_POST['ngay_sinh'], $_POST['dia_chi'], 'giang_vien', '');
        header('Location: ' . URL_ROOT . '/admin/teacher/?finish=add');
    }
?>

<section class="content-header">
    <div class="container-fluid">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?=URL_ROOT?>/admin/"><i class="fas fa-home"></i></a></li>
            <li class="breadcrumb-item"><a href="<?=URL_ROOT?>/admin/teacher/">Giảng viên</a></li>
            <li class="breadcrumb-item active">Thêm</li>
        </ol>
    </div>
</section>
<section class="content">
    <div class="container-fluid">
        <div class="card">
            <div class="card-body">
                <form class="row" method="POST">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Tên giảng viên</label>
                        <input name="ho_ten_tk" type="text" class="form-control">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Email</label>
                        <input name="email" type="email" class="form-control">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Số điện thoại</label>
                        <input name="sdt" type="text" class="form-control">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Giới tính</label>
                        <select class="form-control" name="gioi_tinh">
                            <option value="Nam">Nam</option>
                            <option value="Nữ">Nữ</option>
                        </select>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Ngày sinh</label>
                        <input name="ngay_sinh" type="date" class="form-control">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Địa chỉ</label>
                        <input name="dia_chi" type="text" class="form-control">
                    </div>
                    <div class="col-md-12 mb-3">
                        <button class="btn btn-primary rounded-pill">
                            <i class="far fa-save"></i>
                            <span>Lưu</span>
                        </button>
                        <a href="<?=URL_ROOT?>/admin/teacher" class="btn btn-danger rounded-pill">
                            <i class="fas fa-ban"></i>
                            <span>Huỷ bỏ</span>
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<?php include '../footer.php'?>
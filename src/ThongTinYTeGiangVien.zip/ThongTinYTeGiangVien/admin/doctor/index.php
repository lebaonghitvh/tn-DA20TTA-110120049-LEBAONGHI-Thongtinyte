<?php include '../header.php'?>
<?php
    include '../../models/AccountDB.php';

    if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['del-id'])) {
        AccountDB::DeleteAccount($_GET['del-id']);
        header('Location: ' . URL_ROOT . '/admin/doctor/?finish=delete');
    }

    $doctorList = AccountDB::GetList('bac_si');
?>

<section class="content-header">
    <div class="container-fluid">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?=URL_ROOT?>/admin/"><i class="fas fa-home"></i></a></li>
            <li class="breadcrumb-item"><a href="<?=URL_ROOT?>/admin/doctor/">Bác sĩ</a></li>
            <li class="breadcrumb-item active">Danh sách</li>
        </ol>
    </div>
</section>
<section class="content">
    <div class="container-fluid">
        <?php include '../alert.php'?>

        <div class="mb-3">
            <a href="<?=URL_ROOT?>/admin/doctor/add.php" class="btn btn-success rounded-pill">
                <i class="fas fa-pencil-alt"></i>
                <span>Thêm mới</span>
            </a>
        </div>

        <div class="card">
            <div class="card-body">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr class="bg-success">
                            <th>Bác sĩ</th>
                            <th>Email</th>
                            <th>Số điện thoại</th>
                            <th>Giới tính</th>
                            <th>Ngày sinh</th>
                            <th width="111"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($doctorList as $item) {?>
                        <tr>
                            <td><?=$item['ho_ten_tk']?></td>
                            <td><a href="mailto:<?=$item['email']?>"><?=$item['email']?></a></td>
                            <td><a href="tel:<?=$item['sdt']?>"><?=$item['sdt']?></a></td>
                            <td>
                                <?php if ($item['gioi_tinh'] == 'Nam') {?>
                                <span class="badge badge-primary">Nam</span>
                                <?php } else {?>
                                <span class="badge badge-warning">Nữ</span>
                                <?php }?>
                            </td>
                            <td><?=Helper::DateTime($item['ngay_sinh'], 'date')?></td>
                            <td>
                                <a href="<?=URL_ROOT?>/admin/doctor/edit.php?id=<?=$item['ma_tk']?>" class="btn btn-warning rounded-circle"><i class="fas fa-pencil-alt"></i></a>
                                <a href="?del-id=<?=$item['ma_tk']?>" class="btn btn-danger rounded-circle"><i class="far fa-trash-alt"></i></a>
                            </td>
                        </tr>
                        <?php }?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>
<?php include '../footer.php'?>
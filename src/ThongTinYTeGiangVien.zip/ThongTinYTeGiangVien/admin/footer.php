</div>
</div>

<!-- jQuery -->
<script src="<?=URL_ROOT?>/templates/admin/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?=URL_ROOT?>/templates/admin/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- Summernote -->
<script src="<?=URL_ROOT?>/templates/admin/plugins/summernote/summernote-bs4.min.js"></script>
<!-- AdminLTE App -->
<script src="<?=URL_ROOT?>/templates/admin/dist/js/adminlte.min.js"></script>
<script>
$(function() {
    $('#summernote').summernote()
})
</script>
</body>

</html>

<?php ob_end_flush();?>
<?php include '../header.php'?>
<?php
    include '../../models/HealthRecordDB.php';
    include '../../models/AccountDB.php';

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        HealthRecordDB::AddHealthRecord(
            $_POST['tien_su_benh'],
            $_POST['chieu_cao'],
            $_POST['can_nang'],
            $_POST['bmi'],
            $_POST['tuan_hoan'],
            $_POST['ho_hap'],
            $_POST['tieu_hoa'],
            $_POST['than'],
            $_POST['noi_tiet'],
            $_POST['xuong'],
            $_POST['than_kinh'],
            $_POST['ngoai_khoa'],
            $_POST['san_khoa'],
            $_POST['mat_trai'],
            $_POST['mat_phai'],
            $_POST['mat_trai_co_kinh'],
            $_POST['mat_phai_co_kinh'],
            $_POST['benh_mat'],
            $_POST['tai_mui_hong'],
            $_POST['tai_phai'],
            $_POST['tai_trai'],
            $_POST['benh_ve_tai'],
            $_POST['rang_ham_mat'],
            $_POST['ham_tren'],
            $_POST['ham_duoi'],
            $_POST['benh_ve_rang'],
            $_POST['da_lieu'],
            $_POST['ngay_kham'],
            $_POST['ma_bac_si'],
            $_POST['ma_giang_vien']
        );
        header('Location: ' . URL_ROOT . '/admin/health-record/?finish=add');
    }

    $doctorList = AccountDB::GetList('bac_si');
    $teacherList = AccountDB::GetList('giang_vien');
?>

<section class="content-header">
    <div class="container-fluid">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?=URL_ROOT?>/admin/"><i class="fas fa-home"></i></a></li>
            <li class="breadcrumb-item"><a href="<?=URL_ROOT?>/admin/health-record/">Hồ sơ sức khoẻ</a></li>
            <li class="breadcrumb-item active">Thêm</li>
        </ol>
    </div>
</section>
<section class="content">
    <div class="container-fluid">
        <div class="card">
            <div class="card-body">
                <form class="row" method="POST">
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Giảng viên</label>
                        <select class="form-control" name="ma_giang_vien">
                            <?php foreach ($teacherList as $item) {?>
                            <option value="<?=$item['ma_tk']?>"><?=$item['ho_ten_tk']?></option>
                            <?php }?>
                        </select>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Bác sĩ</label>
                        <select class="form-control" name="ma_bac_si">
                            <?php foreach ($doctorList as $item) {?>
                            <option value="<?=$item['ma_tk']?>"><?=$item['ho_ten_tk']?></option>
                            <?php }?>
                        </select>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Ngày khám</label>
                        <input name="ngay_kham" type="date" class="form-control">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Chiều cao</label>
                        <input name="chieu_cao" type="text" class="form-control">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Cân nặng</label>
                        <input name="can_nang" type="text" class="form-control">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">BMI</label>
                        <input name="bmi" type="text" class="form-control">
                    </div>
                    <div class="col-md-12 mb-3">
                        <label class="form-label">Tuần hoàn</label>
                        <input name="tuan_hoan" type="text" class="form-control">
                    </div>
                    <div class="col-md-12 mb-3">
                        <label class="form-label">Hô hấp</label>
                        <input name="ho_hap" type="text" class="form-control">
                    </div>
                    <div class="col-md-12 mb-3">
                        <label class="form-label">Tiêu hoá</label>
                        <input name="tieu_hoa" type="text" class="form-control">
                    </div>
                    <div class="col-md-12 mb-3">
                        <label class="form-label">Thận</label>
                        <input name="than" type="text" class="form-control">
                    </div>
                    <div class="col-md-12 mb-3">
                        <label class="form-label">Nội tiết</label>
                        <input name="noi_tiet" type="text" class="form-control">
                    </div>
                    <div class="col-md-12 mb-3">
                        <label class="form-label">Xương</label>
                        <input name="xuong" type="text" class="form-control">
                    </div>
                    <div class="col-md-12 mb-3">
                        <label class="form-label">Thần kinh</label>
                        <input name="than_kinh" type="text" class="form-control">
                    </div>
                    <div class="col-md-12 mb-3">
                        <label class="form-label">Ngoại khoa</label>
                        <input name="ngoai_khoa" type="text" class="form-control">
                    </div>
                    <div class="col-md-12 mb-3">
                        <label class="form-label">Sản khoa</label>
                        <input name="san_khoa" type="text" class="form-control">
                    </div>
                    <div class="col-md-3 mb-3">
                        <label class="form-label">Mắt trái không kính</label>
                        <input name="mat_trai" type="number" class="form-control" value="0">
                    </div>
                    <div class="col-md-3 mb-3">
                        <label class="form-label">Mắt phải không kính</label>
                        <input name="mat_phai" type="number" class="form-control" value="0">
                    </div>
                    <div class="col-md-3 mb-3">
                        <label class="form-label">Mắt trái có kính</label>
                        <input name="mat_trai_co_kinh" type="number" class="form-control" value="0">
                    </div>
                    <div class="col-md-3 mb-3">
                        <label class="form-label">Mắt phải có kính</label>
                        <input name="mat_phai_co_kinh" type="number" class="form-control" value="0">
                    </div>
                    <div class="col-md-12 mb-3">
                        <label class="form-label">Bệnh về mắt</label>
                        <input name="benh_mat" type="text" class="form-control">
                    </div>
                    <div class="col-md-12 mb-3">
                        <label class="form-label">Tai mũi họng</label>
                        <input name="tai_mui_hong" type="text" class="form-control">
                    </div>
                    <div class="col-md-12 mb-3">
                        <label class="form-label">Tai trái</label>
                        <input name="tai_trai" type="text" class="form-control">
                    </div>
                    <div class="col-md-12 mb-3">
                        <label class="form-label">Tai phải</label>
                        <input name="tai_phai" type="text" class="form-control">
                    </div>
                    <div class="col-md-12 mb-3">
                        <label class="form-label">Bệnh về tai</label>
                        <input name="benh_ve_tai" type="text" class="form-control">
                    </div>
                    <div class="col-md-12 mb-3">
                        <label class="form-label">Răng hàm mặt</label>
                        <input name="rang_ham_mat" type="text" class="form-control">
                    </div>
                    <div class="col-md-12 mb-3">
                        <label class="form-label">Hàm trên</label>
                        <input name="ham_tren" type="text" class="form-control">
                    </div>
                    <div class="col-md-12 mb-3">
                        <label class="form-label">Hàm dưới</label>
                        <input name="ham_duoi" type="text" class="form-control">
                    </div>
                    <div class="col-md-12 mb-3">
                        <label class="form-label">Bệnh về răng</label>
                        <input name="benh_ve_rang" type="text" class="form-control">
                    </div>
                    <div class="col-md-12 mb-3">
                        <label class="form-label">Da liễu</label>
                        <input name="da_lieu" type="text" class="form-control">
                    </div>
                    <div class="col-md-12 mb-3">
                        <label class="form-label">Tiền sử bệnh</label>
                        <input name="tien_su_benh" type="text" class="form-control">
                    </div>
                    <div class="col-md-12 mb-3">
                        <button class="btn btn-primary rounded-pill">
                            <i class="far fa-save"></i>
                            <span>Lưu</span>
                        </button>
                        <a href="<?=URL_ROOT?>/admin/doctor" class="btn btn-danger rounded-pill">
                            <i class="fas fa-ban"></i>
                            <span>Huỷ bỏ</span>
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<?php include '../footer.php'?>
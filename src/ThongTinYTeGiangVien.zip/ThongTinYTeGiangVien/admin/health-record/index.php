<?php include '../header.php'?>
<?php
    include '../../models/HealthRecordDB.php';

    if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['del-id'])) {
        HealthRecordDB::DeleteHealthRecord($_GET['del-id']);
        header('Location: ' . URL_ROOT . '/admin/health-record/?finish=delete');
    }

    if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['action']) && $_GET['action'] == 'export-excel-teacher') {
        ExportExcel::HealthRecordTeacher(HealthRecordDB::GetList('', $_SESSION['ma_tk']));
    }

    $healthRecordList = HealthRecordDB::GetList('', '');
    if ($_SESSION['quyen'] === 'bac_si') {
        $healthRecordList = HealthRecordDB::GetList($_SESSION['ma_tk'], '');
    }
    if ($_SESSION['quyen'] === 'giang_vien') {
        $healthRecordList = HealthRecordDB::GetList('', $_SESSION['ma_tk']);
    }
?>

<section class="content-header">
    <div class="container-fluid">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?=URL_ROOT?>/admin/"><i class="fas fa-home"></i></a></li>
            <li class="breadcrumb-item"><a href="<?=URL_ROOT?>/admin/health-record/">Hồ sơ sức khoẻ</a></li>
            <li class="breadcrumb-item active">Danh sách</li>
        </ol>
    </div>
</section>
<section class="content">
    <div class="container-fluid">
        <?php include '../alert.php'?>

        <?php if ($_SESSION['quyen'] === 'bac_si') {?>
        <div class="mb-3">
            <a href="<?=URL_ROOT?>/admin/health-record/add.php" class="btn btn-success rounded-pill">
                <i class="fas fa-pencil-alt"></i>
                <span>Thêm mới</span>
            </a>
        </div>
        <?php }?>

        <?php if ($_SESSION['quyen'] === 'giang_vien') {?>
        <div class="mb-3">
            <a href="?action=export-excel-teacher" class="btn btn-primary">
                <i class="fas fa-file-excel"></i>
                <span>Xuất excel</span>
            </a>
        </div>
        <?php }?>

        <div class="accordion" id="accordion">
            <?php foreach ($healthRecordList as $item) {?>
            <div class="card">
                <div class="card-header">
                    <h2 class="mb-0">
                        <button class="btn btn-link btn-block text-left d-flex align-items-center justify-content-between" type="button" data-toggle="collapse" data-target="#collapse<?=$item['ma_hssk']?>">
                            <div>
                                <span>Hồ sơ: </span>
                                <b><?=$item['ma_hssk']?></b>
                            </div>
                            <div>
                                <span>Bác sĩ: </span>
                                <b><?=$item['ho_ten_bs']?></b>
                            </div>
                            <div>
                                <span>Giảng viên: </span>
                                <b><?=$item['ho_ten_tk']?></b>
                            </div>
                            <div>
                                <span>Ngày khám: </span>
                                <b><?=Helper::DateTime($item['ngay_kham'], 'date')?></b>
                            </div>
                        </button>
                    </h2>
                </div>

                <div id="collapse<?=$item['ma_hssk']?>" class="collapse" data-parent="#accordion">
                    <div class="card-body">
                        <div class="d-flex align-items-center justify-content-end mb-2">
                            <?php if ($_SESSION['quyen'] == 'bac_si') {?>
                            <a href="<?=URL_ROOT?>/admin/health-record/edit.php?id=<?=$item['ma_hssk']?>" class="btn btn-warning rounded-circle"><i class="fas fa-pencil-alt"></i></a>
                            <a href="?del-id=<?=$item['ma_hssk']?>" class="btn btn-danger rounded-circle"><i class="far fa-trash-alt"></i></a>
                            <?php }?>
                        </div>
                        <table class="table table-bordered">
                            <tbody>
                                <tr>
                                    <td><b>Chiều cao</b></td>
                                    <td><?=$item['chieu_cao']?></td>
                                    <td><b>Cân nặng</b></td>
                                    <td><?=$item['can_nang']?></td>
                                    <td><b>BMI</b></td>
                                    <td><?=$item['bmi']?></td>
                                </tr>
                                <tr>
                                    <td><b>Tuần hoàn</b></td>
                                    <td colspan="5"><?=$item['tuan_hoan']?></td>
                                </tr>
                                <tr>
                                    <td><b>Hô hấp</b></td>
                                    <td colspan="5"><?=$item['ho_hap']?></td>
                                </tr>
                                <tr>
                                    <td><b>Tiêu hoá</b></td>
                                    <td colspan="5"><?=$item['tieu_hoa']?></td>
                                </tr>
                                <tr>
                                    <td><b>Thận</b></td>
                                    <td colspan="5"><?=$item['than']?></td>
                                </tr>
                                <tr>
                                    <td><b>Nội tiết</b></td>
                                    <td colspan="5"><?=$item['noi_tiet']?></td>
                                </tr>
                                <tr>
                                    <td><b>Xương</b></td>
                                    <td colspan="5"><?=$item['xuong']?></td>
                                </tr>
                                <tr>
                                    <td><b>Thần kinh</b></td>
                                    <td colspan="5"><?=$item['than_kinh']?></td>
                                </tr>
                                <tr>
                                    <td><b>Ngoại khoa</b></td>
                                    <td colspan="5"><?=$item['ngoai_khoa']?></td>
                                </tr>
                                <tr>
                                    <td><b>Sản khoa</b></td>
                                    <td colspan="5"><?=$item['san_khoa']?></td>
                                </tr>
                                <tr>
                                    <td><b>Mắt không kính</b></td>
                                    <td colspan="2">
                                        <span>Trái: <?=$item['mat_trai']?></span>
                                        <span>Phải: <?=$item['mat_phai']?></span>
                                    </td>
                                    <td><b>Mắt có kính</b></td>
                                    <td colspan="2">
                                        <span>Trái: <?=$item['mat_trai_co_kinh']?></span>
                                        <span>Phải: <?=$item['mat_phai_co_kinh']?></span>
                                    </td>
                                </tr>
                                <tr>
                                    <td><b>Bệnh về mắt</b></td>
                                    <td colspan="5"><?=$item['benh_mat']?></td>
                                </tr>
                                <tr>
                                    <td><b>Tai mũi họng</b></td>
                                    <td colspan="5"><?=$item['tai_mui_hong']?></td>
                                </tr>
                                <tr>
                                    <td><b>Tai trái</b></td>
                                    <td colspan="5"><?=$item['tai_trai']?></td>
                                </tr>
                                <tr>
                                    <td><b>Tai phải</b></td>
                                    <td colspan="5"><?=$item['tai_phai']?></td>
                                </tr>
                                <tr>
                                    <td><b>Bệnh về tai</b></td>
                                    <td colspan="5"><?=$item['benh_ve_tai']?></td>
                                </tr>
                                <tr>
                                    <td><b>Da liễu</b></td>
                                    <td colspan="5"><?=$item['da_lieu']?></td>
                                </tr>
                                <tr>
                                    <td><b>Tiền sử bệnh</b></td>
                                    <td colspan="5"><?=$item['tien_su_benh']?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?php }?>
        </div>
    </div>
</section>
<?php include '../footer.php'?>
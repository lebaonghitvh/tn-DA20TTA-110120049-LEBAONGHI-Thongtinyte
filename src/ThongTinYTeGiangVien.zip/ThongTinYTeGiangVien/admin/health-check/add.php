<?php include '../header.php'?>
<?php
    include '../../models/AccountDB.php';
    include '../../models/HealthCheckDB.php';
    include '../../models/HealthServiceDB.php';

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        HealthCheckDB::AddHealthCheck($_POST['ma_tk'], $_POST['ma_dich_vu'], $_POST['ngay_kham'], $_POST['gio_kham'], 'dang_cho');
        header('Location: ' . URL_ROOT . '/admin/health-check/?finish=add');
    }

    $relativeList = AccountDB::GetRelativeList($_SESSION['ma_tk']);
    $healthServiceList = HealthServiceDB::GetList();
?>

<section class="content-header">
    <div class="container-fluid">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?=URL_ROOT?>/admin/"><i class="fas fa-home"></i></a></li>
            <li class="breadcrumb-item"><a href="<?=URL_ROOT?>/admin/health-check/">Đặt lịch khám sức khoẻ</a></li>
            <li class="breadcrumb-item active">Thêm</li>
        </ol>
    </div>
</section>
<section class="content">
    <div class="container-fluid">
        <div class="card">
            <div class="card-body">
                <form class="row" method="POST">
                    <div class="col-md-12 mb-3">
                        <label class="form-label">Người khám (Bản thân hoặc thân nhân)</label>
                        <select class="form-control" name="ma_tk">
                            <option value="<?=$_SESSION['ma_tk']?>">Bản thân</option>
                            <?php foreach ($relativeList as $item) {?>
                            <option value="<?=$item['ma_tk']?>"><?=$item['ho_ten_tk']?></option>
                            <?php }?>
                        </select>
                    </div>
                    <div class="col-md-12 mb-3">
                        <label class="form-label">Dịch vụ</label>
                        <select class="form-control" name="ma_dich_vu">
                            <?php foreach ($healthServiceList as $item) {?>
                            <option value="<?=$item['ma_dich_vu']?>"><?=$item['ten_dich_vu']?></option>
                            <?php }?>
                        </select>
                    </div>
                    <div class="form-group col-lg-6">
                        <label for="inputDate">Ngày khám</label>
                        <input type="date" class="form-control" name="ngay_kham">
                    </div>
                    <div class="form-group col-lg-6">
                        <label>Giờ khám</label>
                        <select name="gio_kham" class="form-control wide">
                            <?php for ($i = 7; $i < 17; $i++) {?>
                            <option value="<?=$i?>:00:00"><?=$i?>:00</option>
                            <?php }?>
                        </select>
                    </div>
                    <div class="col-md-12 mb-3">
                        <button class="btn btn-primary rounded-pill">
                            <i class="far fa-save"></i>
                            <span>Lưu</span>
                        </button>
                        <a href="<?=URL_ROOT?>/admin/health-check" class="btn btn-danger rounded-pill">
                            <i class="fas fa-ban"></i>
                            <span>Huỷ bỏ</span>
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<?php include '../footer.php'?>
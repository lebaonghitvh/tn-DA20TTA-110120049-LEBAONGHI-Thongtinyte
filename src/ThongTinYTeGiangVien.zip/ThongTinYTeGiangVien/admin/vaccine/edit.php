<?php include '../header.php'?>
<?php
    include '../../models/VaccineDB.php';

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        VaccineDB::UpdateVaccine($_GET['id'], $_POST['ten_vac_xin'], $_POST['ten_khoa_hoc'], $_POST['nha_san_xuat'], $_POST['doi_tuong_tiem'], $_POST['lieu_trinh_tiem'], $_POST['gia'], $_POST['tac_dung_phu'], $_POST['luu_y']);
        header('Location: ' . URL_ROOT . '/admin/vaccine/?finish=update');
    }

    $vaccine = VaccineDB::GetItemByID($_GET['id']);
?>

<section class="content-header">
    <div class="container-fluid">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?=URL_ROOT?>/admin/"><i class="fas fa-home"></i></a></li>
            <li class="breadcrumb-item"><a href="<?=URL_ROOT?>/admin/vaccine/">Vắc xin</a></li>
            <li class="breadcrumb-item active">Chỉnh sửa</li>
        </ol>
    </div>
</section>
<section class="content">
    <div class="container-fluid">
        <div class="card">
            <div class="card-body">
                <form class="row" method="POST">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Tên vắc xin</label>
                        <input name="ten_vac_xin" type="text" class="form-control" value="<?=$vaccine['ten_vac_xin']?>">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Tên khoa học</label>
                        <input name="ten_khoa_hoc" type="text" class="form-control" value="<?=$vaccine['ten_khoa_hoc']?>">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Nhà sản xuất</label>
                        <input name="nha_san_xuat" type="text" class="form-control" value="<?=$vaccine['nha_san_xuat']?>">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Đối tượng tiệm</label>
                        <input name="doi_tuong_tiem" type="text" class="form-control" value="<?=$vaccine['doi_tuong_tiem']?>">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Liệu trình tiêm</label>
                        <input name="lieu_trinh_tiem" type="text" class="form-control" value="<?=$vaccine['lieu_trinh_tiem']?>">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Giá bán</label>
                        <input name="gia" type="number" class="form-control" value="<?=$vaccine['gia']?>">
                    </div>
                    <div class="col-md-12 mb-3">
                        <label class="form-label">Tác dụng phụ</label>
                        <input name="tac_dung_phu" type="text" class="form-control" value="<?=$vaccine['tac_dung_phu']?>">
                    </div>
                    <div class="col-md-12 mb-3">
                        <label class="form-label">Lưu ý</label>
                        <input name="luu_y" type="text" class="form-control" value="<?=$vaccine['luu_y']?>">
                    </div>
                    <div class="col-md-12 mb-3">
                        <button class="btn btn-primary rounded-pill">
                            <i class="far fa-save"></i>
                            <span>Lưu</span>
                        </button>
                        <a href="<?=URL_ROOT?>/admin/vaccine" class="btn btn-danger rounded-pill">
                            <i class="fas fa-ban"></i>
                            <span>Huỷ bỏ</span>
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<?php include '../footer.php'?>
<?php include '../header.php'?>
<?php
    include '../../models/VaccineDB.php';

    if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['del-id'])) {
        VaccineDB::DeleteVaccine($_GET['del-id']);
        header('Location: ' . URL_ROOT . '/admin/vaccine/?finish=delete');
    }

    $vaccineList = VaccineDB::GetList('bac_si');
?>

<section class="content-header">
    <div class="container-fluid">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?=URL_ROOT?>/admin/"><i class="fas fa-home"></i></a></li>
            <li class="breadcrumb-item"><a href="<?=URL_ROOT?>/admin/vaccine/">Vắc xin</a></li>
            <li class="breadcrumb-item active">Danh sách</li>
        </ol>
    </div>
</section>
<section class="content">
    <div class="container-fluid">
        <?php include '../alert.php'?>

        <div class="mb-3">
            <a href="<?=URL_ROOT?>/admin/vaccine/add.php" class="btn btn-success rounded-pill">
                <i class="fas fa-pencil-alt"></i>
                <span>Thêm mới</span>
            </a>
        </div>

        <div class="card">
            <div class="card-body">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr class="bg-success">
                            <th>Tên vắc xin</th>
                            <th>Tên khoa học</th>
                            <th>Nhà sản xuất</th>
                            <th>Đối tượng tiêm</th>
                            <th>Liệu trình tiêm</th>
                            <th>Giá bán</th>
                            <th width="111"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($vaccineList as $item) {?>
                        <tr>
                            <td><?=$item['ten_vac_xin']?></td>
                            <td><?=$item['ten_khoa_hoc']?></td>
                            <td><?=$item['nha_san_xuat']?></td>
                            <td><?=$item['doi_tuong_tiem']?></td>
                            <td><?=$item['lieu_trinh_tiem']?></td>
                            <td><?=Helper::Currency($item['gia'])?></td>
                            <td>
                                <a href="<?=URL_ROOT?>/admin/vaccine/edit.php?id=<?=$item['vac_xin_id']?>" class="btn btn-warning rounded-circle"><i class="fas fa-pencil-alt"></i></a>
                                <a href="?del-id=<?=$item['vac_xin_id']?>" class="btn btn-danger rounded-circle"><i class="far fa-trash-alt"></i></a>
                            </td>
                        </tr>
                        <?php }?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>
<?php include '../footer.php'?>
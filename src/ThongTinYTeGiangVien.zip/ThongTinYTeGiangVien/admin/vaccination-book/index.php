<?php include '../header.php'?>
<?php
    include '../../models/VaccinationBookDB.php';

    if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['del-id'])) {
        VaccinationBookDB::DeleteVaccinationBook($_GET['del-id']);
        header('Location: ' . URL_ROOT . '/admin/vaccination-book/?finish=delete');
    }

    if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['action']) && $_GET['action'] == 'export-excel') {
        ExportExcel::VaccinationBook(VaccinationBookDB::GetList(''));
    }

    $vaccinationBookList = VaccinationBookDB::GetList('');
    if ($_SESSION['quyen'] === 'giang_vien') {
        $vaccinationBookList = VaccinationBookDB::GetMyOrRelativeList($_SESSION['ma_tk']);
    }
?>

<section class="content-header">
    <div class="container-fluid">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?=URL_ROOT?>/admin/"><i class="fas fa-home"></i></a></li>
            <li class="breadcrumb-item"><a href="<?=URL_ROOT?>/admin/vaccination-book/">Đặt lịch tiêm chủng</a></li>
            <li class="breadcrumb-item active">Danh sách</li>
        </ol>
    </div>
</section>
<section class="content">
    <div class="container-fluid">
        <?php include '../alert.php'?>

        <?php if ($_SESSION['quyen'] === 'giang_vien') {?>
        <div class="mb-3">
            <a href="<?=URL_ROOT?>/admin/vaccination-book/add.php" class="btn btn-success rounded-pill">
                <i class="fas fa-pencil-alt"></i>
                <span>Thêm mới</span>
            </a>
        </div>
        <?php }?>

        <?php if ($_SESSION['quyen'] === 'admin') {?>
        <div class="mb-3">
            <a href="?action=export-excel" class="btn btn-primary">
                <i class="fas fa-file-excel"></i>
                <span>Xuất excel</span>
            </a>
        </div>
        <?php }?>

        <div class="card">
            <div class="card-body">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr class="bg-success">
                            <th>Khách hàng</th>
                            <th>Loại vắc xin</th>
                            <th>Ngày khám</th>
                            <th>Giờ khám</th>
                            <th>Trạng thái</th>
                            <th width="111"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($vaccinationBookList as $item) {?>
                        <tr>
                            <td><?=$item['ho_ten_tk']?></td>
                            <td><?=$item['ten_vac_xin']?></td>
                            <td><?=$item['ngay_kham']?></td>
                            <td><?=$item['gio_kham']?></td>
                            <td>
                                <?php if ($item['trang_thai'] === 'dang_cho') {?>
                                <span class="badge badge-warning">Đang chờ</span>
                                <?php } else if ($item['trang_thai'] === 'da_xac_nhan') {?>
                                <span class="badge badge-info">Đã xác nhận</span>
                                <?php } else if ($item['trang_thai'] === 'da_kham') {?>
                                <span class="badge badge-success">Đã khám</span>
                                <?php } else {?>
                                <span class="badge badge-danger">Đã huỷ</span>
                                <?php }?>
                            </td>
                            <td>
                                <?php if ($_SESSION['quyen'] === 'admin') {?>
                                <a href="<?=URL_ROOT?>/admin/vaccination-book/edit.php?id=<?=$item['ma_dat_lich_tiem_chung']?>" class="btn btn-warning rounded-circle"><i class="fas fa-pencil-alt"></i></a>
                                <?php }?>
                                <a href="?del-id=<?=$item['ma_dat_lich_tiem_chung']?>" class="btn btn-danger rounded-circle"><i class="far fa-trash-alt"></i></a>
                            </td>
                        </tr>
                        <?php }?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>
<?php include '../footer.php'?>
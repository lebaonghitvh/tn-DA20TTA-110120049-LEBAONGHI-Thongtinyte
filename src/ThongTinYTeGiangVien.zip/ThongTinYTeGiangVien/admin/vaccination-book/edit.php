<?php include '../header.php'?>
<?php
    include '../../models/VaccinationBookDB.php';

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        VaccinationBookDB::UpdateVaccinationBookStatus($_GET['id'], $_POST['trang_thai']);
        header('Location: ' . URL_ROOT . '/admin/health-check/?finish=update');
    }

    $vaccinationBook = VaccinationBookDB::GetItemByID($_GET['id']);
?>

<section class="content-header">
    <div class="container-fluid">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?=URL_ROOT?>/admin/"><i class="fas fa-home"></i></a></li>
            <li class="breadcrumb-item"><a href="<?=URL_ROOT?>/admin/vaccination-book/">Đặt lịch tiêm chủng</a></li>
            <li class="breadcrumb-item active">Chỉnh sửa</li>
        </ol>
    </div>
</section>
<section class="content">
    <div class="container-fluid">
        <div class="card">
            <div class="card-body">
                <form class="row" method="POST">
                    <div class="col-md-12 mb-3">
                        <label class="form-label">Trạng thái</label>
                        <select class="form-control" name="trang_thai">
                            <option value="dang_cho" <?=$vaccinationBook['trang_thai'] == 'dang_cho' ? 'selected' : ''?>>Đang chờ</option>
                            <option value="da_xac_nhan" <?=$vaccinationBook['trang_thai'] == 'da_xac_nhan' ? 'selected' : ''?>>Đã xác nhận</option>
                            <option value="da_kham" <?=$vaccinationBook['trang_thai'] == 'da_kham' ? 'selected' : ''?>>Đã khám</option>
                            <option value="da_huy" <?=$vaccinationBook['trang_thai'] == 'da_huy' ? 'selected' : ''?>>Đã huỷ</option>
                        </select>
                    </div>
                    <div class="col-md-12 mb-3">
                        <button class="btn btn-primary rounded-pill">
                            <i class="far fa-save"></i>
                            <span>Lưu</span>
                        </button>
                        <a href="<?=URL_ROOT?>/admin/health-check" class="btn btn-danger rounded-pill">
                            <i class="fas fa-ban"></i>
                            <span>Huỷ bỏ</span>
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<?php include '../footer.php'?>
<?php include '../header.php'?>
<?php
    include '../../models/HealthServiceDB.php';

    if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['del-id'])) {
        HealthServiceDB::DeleteHealthService($_GET['del-id']);
        header('Location: ' . URL_ROOT . '/admin/health-service/?finish=delete');
    }

    $healthServiceList = HealthServiceDB::GetList('bac_si');
?>

<section class="content-header">
    <div class="container-fluid">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?=URL_ROOT?>/admin/"><i class="fas fa-home"></i></a></li>
            <li class="breadcrumb-item"><a href="<?=URL_ROOT?>/admin/health-service/">Dịch vụ y tế</a></li>
            <li class="breadcrumb-item active">Danh sách</li>
        </ol>
    </div>
</section>
<section class="content">
    <div class="container-fluid">
        <?php include '../alert.php'?>

        <div class="mb-3">
            <a href="<?=URL_ROOT?>/admin/health-service/add.php" class="btn btn-success rounded-pill">
                <i class="fas fa-pencil-alt"></i>
                <span>Thêm mới</span>
            </a>
        </div>

        <div class="card">
            <div class="card-body">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr class="bg-success">
                            <th>Tên dịch vụ</th>
                            <th>Giá tiền</th>
                            <th width="111"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($healthServiceList as $item) {?>
                        <tr>
                            <td><?=$item['ten_dich_vu']?></td>
                            <td><?=Helper::Currency($item['gia_tien'])?></td>
                            <td>
                                <a href="<?=URL_ROOT?>/admin/health-service/edit.php?id=<?=$item['ma_dich_vu']?>" class="btn btn-warning rounded-circle"><i class="fas fa-pencil-alt"></i></a>
                                <a href="?del-id=<?=$item['ma_dich_vu']?>" class="btn btn-danger rounded-circle"><i class="far fa-trash-alt"></i></a>
                            </td>
                        </tr>
                        <?php }?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>
<?php include '../footer.php'?>
<?php include '../header.php'?>
<?php
    include '../../models/HealthServiceDB.php';

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        HealthServiceDB::UpdateHealthService($_GET['id'], $_POST['ten_dich_vu'], $_POST['gia_tien'], $_POST['mo_ta']);
        header('Location: ' . URL_ROOT . '/admin/health-service/?finish=update');
    }

    $healthService = HealthServiceDB::GetItemByID($_GET['id']);
?>

<section class="content-header">
    <div class="container-fluid">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?=URL_ROOT?>/admin/"><i class="fas fa-home"></i></a></li>
            <li class="breadcrumb-item"><a href="<?=URL_ROOT?>/admin/health-service/">Dịch vụ y tế</a></li>
            <li class="breadcrumb-item active">Chỉnh sửa</li>
        </ol>
    </div>
</section>
<section class="content">
    <div class="container-fluid">
        <div class="card">
            <div class="card-body">
                <form class="row" method="POST">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Tên dịch vụ</label>
                        <input name="ten_dich_vu" type="text" class="form-control" value="<?=$healthService['ten_dich_vu']?>">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Giá tiền</label>
                        <input name="gia_tien" type="number" class="form-control" value="<?=$healthService['gia_tien']?>">
                    </div>
                    <div class="col-md-12 mb-3">
                        <label class="form-label">Mô tả</label>
                        <textarea id="summernote" name="mo_ta"><?=$healthService['mo_ta']?></textarea>
                    </div>
                    <div class="col-md-12 mb-3">
                        <button class="btn btn-primary rounded-pill">
                            <i class="far fa-save"></i>
                            <span>Lưu</span>
                        </button>
                        <a href="<?=URL_ROOT?>/admin/health-service" class="btn btn-danger rounded-pill">
                            <i class="fas fa-ban"></i>
                            <span>Huỷ bỏ</span>
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<?php include '../footer.php'?>
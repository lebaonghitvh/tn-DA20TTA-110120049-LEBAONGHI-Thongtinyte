<?php include 'header.php'?>
<?php
    include 'models/AccountDB.php';

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $account = AccountDB::LoginAccount($_POST['email'], $_POST['mat_khau']);
        if (count($account) == 0) {
            $message = 'Tên đăng nhập hoặc mật khẩu không hợp lệ';
        } else {
            $_SESSION['is_login'] = true;
            $_SESSION['ma_tk'] = $account[0]['ma_tk'];
            $_SESSION['ho_ten_tk'] = $account[0]['ho_ten_tk'];
            $_SESSION['quyen'] = $account[0]['quyen'];

            header('Location: ' . URL_ROOT . '?finish=login');
        }
    }
?>

<section class="contact_section layout_padding-top layout_padding-bottom">
    <div class="container">
        <?php if (isset($message)) {?>
        <div class="p-3 bg-danger rounded mb-3 text-white">
            <?=$message?>
        </div>
        <?php }?>
    </div>

    <div class="container">
        <div class="heading_container">
            <h2>Đăng nhập tài khoản</h2>
        </div>
        <div class="row">
            <div class="col-md-7">
                <div class="form_container">
                    <form class="form-row" method="POST">
                        <div class="form-group col-lg-6">
                            <input type="email" name="email" placeholder="Email" />
                        </div>
                        <div class="form-group col-lg-6">
                            <input type="password" name="mat_khau" placeholder="Mật khẩu" />
                        </div>
                        <div class="btn_box">
                            <button>Đăng nhập</button>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-5">
                <div class="img-box">
                    <img src="<?=URL_ROOT?>/templates/home/images/contact-img.jpg" alt="">
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'footer.php'?>
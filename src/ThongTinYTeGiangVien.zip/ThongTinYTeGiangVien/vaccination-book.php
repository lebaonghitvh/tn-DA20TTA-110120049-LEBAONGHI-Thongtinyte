<?php include 'header.php'?>
<?php
    include 'models/VaccineDB.php';
    include 'models/VaccinationBookDB.php';

    if (!isset($_SESSION['is_login'])) {
        header('Location: ' . URL_ROOT . '/login.php');
    }

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        VaccinationBookDB::AddVaccinationBook($_SESSION['ma_tk'], $_POST['ma_vac_xin'], $_POST['ngay_kham'], $_POST['gio_kham'], 'dang_cho');
        $message = 'Đăng ký tiêm chủng';
    }

    $vaccineList = VaccineDB::GetList();
?>

<section class="book_section layout_padding">
    <div class="container">
        <?php if (isset($message)) {?>
        <div class="p-3 bg-success rounded mb-3 text-white">
            <?=$message?>
        </div>
        <?php }?>
    </div>

    <div class="container">
        <div class="row">
            <div class="col">
                <form method="POST">
                    <h4>ĐẶT LỊCH TIÊM CHỦNG</h4>
                    <div class="form-row">
                        <div class="form-group col-lg-12">
                            <label>Loại vắc xin</label>
                            <select name="ma_vac_xin" class="form-control wide">
                                <?php foreach ($vaccineList as $item) {?>
                                <option value="<?=$item['vac_xin_id']?>"><?=$item['ten_vac_xin']?></option>
                                <?php }?>
                            </select>
                        </div>
                        <div class="form-group col-lg-6">
                            <label for="inputDate">Ngày khám</label>
                            <input type="date" class="form-control" name="ngay_kham">
                        </div>
                        <div class="form-group col-lg-6">
                            <label>Giờ khám</label>
                            <select name="gio_kham" class="form-control wide">
                                <?php for ($i = 7; $i < 17; $i++) {?>
                                <option value="<?=$i?>:00:00"><?=$i?>:00</option>
                                <?php }?>
                            </select>
                        </div>
                    </div>
                    <div class="btn-box">
                        <button type="submit" class="btn">Đăng ký</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

<?php include 'footer.php'?>